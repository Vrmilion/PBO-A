<?php

$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'rumahsakit',
    'host' => 'localhost'
);

$con = $sql_details;